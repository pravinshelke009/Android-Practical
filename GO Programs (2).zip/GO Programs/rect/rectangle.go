package rectangle

func Area(len, wid int) int {
	return len * wid
}
